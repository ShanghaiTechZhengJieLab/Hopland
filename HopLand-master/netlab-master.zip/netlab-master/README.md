# netlab

NETLAB toolbox hosted on GitHub for convenience. In the longer term the aim is to work with Ian to make an updated version of netlab available via GitHub. Watch this space.

Here is [the original site](http://www.aston.ac.uk/eas/research/groups/ncrg/resources/netlab/downloads/).
